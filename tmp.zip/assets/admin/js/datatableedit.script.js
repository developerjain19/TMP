(function ($) {
    "use strict";
  $('#example').editableTableWidget({editor: $('<textarea>')});
 $('#example').DataTable({    
     responsive: true
 });
 
   $('#bootstraptable').editableTableWidget({editor: $('<textarea>')});

})(jQuery);
