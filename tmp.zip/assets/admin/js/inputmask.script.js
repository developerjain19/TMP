(function ($) {
    "use strict";
/////////////////// input mask /////////////////////////////
    $('[data-masked]').inputmask();

})(jQuery);
