(function ($) {
    "use strict";

$('#example').footable();
$('#foo-pagination').footable();
})(jQuery);
